rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.default.results bzip2.default
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.L1-2way.results bzip2.L1-2way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.All-2way.results bzip2.All-2way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.L2-4way.results bzip2.L2-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.All-4way.results bzip2.All-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.L1-8way.results bzip2.L1-8way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.L2-Big.results bzip2.L2-Big
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.L1-small.results bzip2.L1-small
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.L1-small-4way.results bzip2.L1-small-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.All-FA.results bzip2.All-FA
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/bzip.gz | ./cacheSim bzip.All-FA-L2Big.results bzip2.All-FA-L2Big
