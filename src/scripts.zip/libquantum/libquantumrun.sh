rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.default.results libquantum.default
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.L1-2way.results libquantum.L1-2way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.All-2way.results libquantum.All-2way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.L2-4way.results libquantum.L2-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.All-4way.results libquantum.All-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.L1-8way.results libquantum.L1-8way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.L2-Big.results libquantum.L2-Big
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.L1-small.results libquantum.L1-small
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.L1-small-4way.results libquantum.L1-small-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.All-FA.results libquantum.All-FA
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/libquantum.gz | ./cacheSim libquantum.All-FA-L2Big.results libquantum.All-FA-L2Big
