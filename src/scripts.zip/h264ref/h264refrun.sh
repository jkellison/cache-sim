rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.default.results h264ref.default
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.L1-2way.results h264ref.L1-2way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.All-2way.results h264ref.All-2way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.L2-4way.results h264ref.L2-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.All-4way.results h264ref.All-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.L1-8way.results h264ref.L1-8way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.L2-Big.results h264ref.L2-Big
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.L1-small.results h264ref.L1-small
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.L1-small-4way.results h264ref.L1-small-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.All-FA.results h264ref.All-FA
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/h264ref.gz | ./cacheSim h264ref.All-FA-L2Big.results h264ref.All-FA-L2Big
