rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.default.results omnetpp.default
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.L1-2way.results omnetpp.L1-2way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.All-2way.results omnetpp.All-2way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.L2-4way.results omnetpp.L2-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.All-4way.results omnetpp.All-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.L1-8way.results omnetpp.L1-8way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.L2-Big.results omnetpp.L2-Big
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.L1-small.results omnetpp.L1-small
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.L1-small-4way.results omnetpp.L1-small-4way
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.All-FA.results omnetpp.All-FA
rm DBUG.txt
zcat ../../../scratch/arp/ecen4593-sp15/traces-long/omnetpp.gz | ./cacheSim omnetpp.All-FA-L2Big.results omnetpp.All-FA-L2Big
